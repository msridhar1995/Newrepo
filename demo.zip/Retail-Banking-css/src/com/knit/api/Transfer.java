package com.knit.api;

public class Transfer {
	private int account_ID;
	private int amount;
	private int t_account_ID;
	public int getAccount_ID() {
		return account_ID;
	}
	public void setAccount_ID(int account_ID) {
		this.account_ID = account_ID;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getT_account_ID() {
		return t_account_ID;
	}
	public void setT_account_ID(int t_account_ID) {
		this.t_account_ID = t_account_ID;
	}

}
